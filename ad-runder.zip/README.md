
# AdRunder — Ads Only Theme (Frontend + Example Server)

This repository contains:
- `public/index.html` — Single-file frontend theme (ads-only) with client-side preview and simulated payment flow.
- `server/index.js` — Example Node.js + Express server demonstrating:
  - Image upload to S3
  - Stripe Checkout session creation
  - Stripe webhook skeleton to mark slots active

## Quick start (local, demo)

1. Copy `.env.example` to `.env` and fill your keys.
2. Install dependencies:
   ```
   npm install
   ```
3. Start server:
   ```
   npm start
   ```
4. Serve `public/index.html` (you can open the file directly in browser for demo). For production, host `public` on the same domain as server or configure CORS.

## Deploy options

### Render / Heroku / DigitalOcean App Platform
- Set environment variables in dashboard (STRIPE keys, AWS keys, S3 bucket, BASE_URL).
- Deploy repo; ensure server listens on `process.env.PORT`.
- Configure webhook endpoint URL in Stripe dashboard: `https://yourdomain.com/webhook`

### Notes
- **Security:** Never expose secret keys in frontend. Use server for Stripe and S3 uploads.
- **Moderation:** After successful payment, mark slots pending approval and use admin panel to approve.
- **Images & CDN:** Optimize images (WebP), use a CDN in front of S3.

If you want, I can:
1) Create a GitHub repo with these files and push it (I will provide the repo contents here for you to paste), or
2) Deploy to Render/Heroku for you if you provide access details, or
3) Provide a ZIP you can download and push to GitHub / deploy yourself.
