require('dotenv').config();
const express = require('express');
const Stripe = require('stripe');
const multer = require('multer');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');

const app = express();
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const upload = multer({ dest: 'uploads/' });
const s3 = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' });

app.use(express.json());

// 1) Upload image endpoint (used by the client to upload ad images securely)
app.post('/upload-image', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file' });
    const fileStream = fs.createReadStream(req.file.path);
    const key = `ads/${Date.now()}-${req.file.originalname}`;
    await s3.send(new PutObjectCommand({
      Bucket: process.env.S3_BUCKET,
      Key: key,
      Body: fileStream,
      ContentType: req.file.mimetype,
      ACL: 'public-read'
    }));
    fs.unlinkSync(req.file.path);
    const publicUrl = process.env.S3_PUBLIC_URL_BASE ? `${process.env.S3_PUBLIC_URL_BASE}/${key}` : `${process.env.BASE_URL}/s3/${key}`;
    return res.json({ url: publicUrl });
  } catch (err) {
    console.error(err); return res.status(500).json({ error: 'upload failed' });
  }
});

// 2) Create Stripe Checkout session
app.post('/create-checkout-session', express.json(), async (req, res) => {
  try {
    const { title, company, imageUrl, amount, duration } = req.body;
    if (!amount || !title || !company) return res.status(400).json({ error: 'Missing fields' });

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [{
        price_data: {
          currency: 'inr',
          product_data: { name: `${title} — ${company}` },
          unit_amount: amount,
        },
        quantity: 1,
      }],
      success_url: `${process.env.BASE_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.BASE_URL}/cancel`,
      metadata: { title, company, imageUrl, duration }
    });

    res.json({ sessionId: session.id });
  } catch (err) { console.error(err); res.status(500).json({ error: err.message }); }
});

// 3) Stripe webhook — mark slot active after payment
app.post('/webhook', bodyParser.raw({type: 'application/json'}), (req, res) => {
  const sig = req.headers['stripe-signature'];
  try {
    const event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      // TODO: save session.metadata into DB and mark ad slot active
      console.log('Payment succeeded for', session.metadata);
    }
    res.json({ received: true });
  } catch (err) {
    console.error('Webhook error', err.message); res.status(400).send(`Webhook Error: ${err.message}`);
  }
});

const PORT = process.env.PORT || 4242;
app.listen(PORT, ()=>console.log('Server listening on', PORT));
